#!/bin/bash

# Log debugging info
LOG_FILE="/tmp/smb_debug.log"
exec >> "$LOG_FILE" 2>&1
echo "Script started at $(date)"

# Ensure proper environment variables
export DISPLAY=:0
export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u)/bus"
echo "Environment: DISPLAY=$DISPLAY, DBUS_SESSION_BUS_ADDRESS=$DBUS_SESSION_BUS_ADDRESS"

# Variables
SERVER="//192.168.1.22/Private/Images"
MOUNT_POINT="/mnt/smb_private_images"
USERNAME="user"
SMB_PASSWORD="H1e2b3i7me?"

# Prompt for sudo password using yad
SUDO_PASSWORD=$(yad --entry --title="Sudo Authentication" --text="Enter your sudo password:" \
    --button=gtk-ok:0 --width=300 --height=100 --center --undecorated --on-top \
    --skip-taskbar --skip-pager --hide-text)

# Check if the sudo password was entered
if [ -z "$SUDO_PASSWORD" ]; then
    echo "No sudo password entered. Exiting."
    notify-send "SMB Mount" "No sudo password entered. Exiting." -u critical
    exit 1
fi

# Validate sudo password
echo "$SUDO_PASSWORD" | sudo -S -v
if [ $? -ne 0 ]; then
    echo "Sudo authentication failed."
    notify-send "SMB Mount" "Sudo authentication failed. Exiting." -u critical
    exit 1
fi

# Ensure the mount point exists
echo "$SUDO_PASSWORD" | sudo -S /bin/mkdir -p "$MOUNT_POINT"
if [ $? -ne 0 ]; then
    echo "Failed to create mount point $MOUNT_POINT."
    notify-send "SMB Mount" "Failed to create mount point $MOUNT_POINT." -u critical
    exit 1
fi

# Attempt to mount the SMB share
echo "$SUDO_PASSWORD" | sudo -S /bin/mount -t cifs "$SERVER" "$MOUNT_POINT" \
    -o username="$USERNAME",password="$SMB_PASSWORD",vers=3.0,uid=$(id -u),gid=$(id -g),file_mode=0777,dir_mode=0777
if [ $? -ne 0 ]; then
    echo "Failed to mount $SERVER to $MOUNT_POINT."
    notify-send "SMB Mount" "Failed to mount $SERVER to $MOUNT_POINT." -u critical
    exit 1
fi

# Confirm success
echo "Successfully mounted $SERVER to $MOUNT_POINT."
notify-send "SMB Mount" "Successfully mounted $SERVER to $MOUNT_POINT." -u normal
exit 0
