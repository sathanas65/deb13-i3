#!/bin/bash

# Log debugging info
LOG_FILE="/tmp/smb_debug.log"
exec >> "$LOG_FILE" 2>&1
echo "Script started at $(date)"

# Ensure proper environment variables
export DISPLAY=:0
export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u)/bus"
echo "Environment: DISPLAY=$DISPLAY, DBUS_SESSION_BUS_ADDRESS=$DBUS_SESSION_BUS_ADDRESS"

# Variables
SERVER="//192.168.1.22/Shared/Media"
MOUNT_POINT="/mnt/smb_share"
USERNAME="user"
SMB_PASSWORD="H1e2b3i7me?"

# Prompt for sudo password using yad
SUDO_PASSWORD=$(yad --entry --title="Sudo Authentication" --text="Enter your sudo password:" \
    --button=gtk-ok:0 --width=300 --height=100 --center --undecorated --on-top \
    --skip-taskbar --skip-pager --hide-text)

# Check if the sudo password was entered
if [ -z "$SUDO_PASSWORD" ]; then
    yad --text="No sudo password entered. Exiting." --button=gtk-ok:0 --width=200 --center
    echo "No sudo password entered. Exiting."
    exit 1
fi

# Validate sudo password
echo "$SUDO_PASSWORD" | sudo -S -v
if [ $? -ne 0 ]; then
    yad --text="Sudo authentication failed. Exiting." --button=gtk-ok:0 --width=200 --center
    echo "Sudo authentication failed."
    exit 1
fi

# Ensure the mount point exists
echo "$SUDO_PASSWORD" | sudo -S /bin/mkdir -p "$MOUNT_POINT"
if [ $? -ne 0 ]; then
    yad --text="Failed to create mount point. Exiting." --button=gtk-ok:0 --width=200 --center
    echo "Failed to create mount point $MOUNT_POINT."
    exit 1
fi

# Attempt to mount the SMB share
echo "$SUDO_PASSWORD" | sudo -S /bin/mount -t cifs "$SERVER" "$MOUNT_POINT" \
    -o username="$USERNAME",password="$SMB_PASSWORD",vers=3.0,uid=$(id -u),gid=$(id -g),file_mode=0777,dir_mode=0777
if [ $? -ne 0 ]; then
    yad --text="Failed to mount the SMB share. Check logs for details." --button=gtk-ok:0 --width=300 --center
    echo "Failed to mount $SERVER to $MOUNT_POINT."
    exit 1
fi

# Confirm success
yad --text="Successfully mounted $SERVER to $MOUNT_POINT." --button=gtk-ok:0 --width=300 --center
echo "Successfully mounted $SERVER to $MOUNT_POINT."
exit 0
